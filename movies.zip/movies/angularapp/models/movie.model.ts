export interface Movie{
  id?:number;
  title:string;
  duration:number;
  genre:string;
  price:number;
  totalSeats:number;
}